from django.shortcuts import redirect

class AdminRequiredMixIns:
    def dispatch(self, request, *args, **kwargs):
        
        user = request.user
        
        if not user.is_authenticated:
            return redirect("/auth/access-denied/")
        
        
        membership = user.memberships.filter(role = "admin").first()
        
        if not membership:
            return redirect("/auth/access-denied/")
        
        return super().dispatch(request, *args, **kwargs)
        
        
        
        